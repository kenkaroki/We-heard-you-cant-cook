const s=globalThis.__sveltekit_1j4y920?.base??"/cantcook",a=globalThis.__sveltekit_1j4y920?.assets??s??"";export{a,s as b};
